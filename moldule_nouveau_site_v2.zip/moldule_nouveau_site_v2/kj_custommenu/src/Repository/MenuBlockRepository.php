<?php


namespace PrestaShop\Module\CustomMenu\Repository;


use Doctrine\ORM\EntityRepository;

class MenuBlockRepository extends EntityRepository
{

}