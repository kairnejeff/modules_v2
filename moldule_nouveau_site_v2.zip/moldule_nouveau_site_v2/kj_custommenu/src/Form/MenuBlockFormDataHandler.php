<?php


namespace PrestaShop\Module\CustomMenu\Form;


use PrestaShop\PrestaShop\Core\Form\IdentifiableObject\DataHandler\FormDataHandlerInterface;

class MenuBlockFormDataHandler implements FormDataHandlerInterface
{
    public function create(array $data)
    {
        // TODO: Implement create() method.
    }

    public function update($id, array $data)
    {
        // TODO: Implement update() method.
    }

}