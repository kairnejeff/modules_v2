<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class Kj_FooterQuestion extends Module
{
    public function __construct() {
        $this->name = 'kj_footerquestion';
        $this->author = 'Jing';
        $this->version = '1.0.0';
        $this->need_instance= 0;
        $this->bootstrap = true;
        $this->tab = 'others';
        parent::__construct();
        $this->ps_versions_compliancy = array(
            'min' => '1.7',
            'max' => _PS_VERSION_
        );
        $this->displayName = $this->l('Footer Question');
        $this->description = $this->l('create an block question in the footer');
    }

    public function install(){
        $html = '<div class="block-title">Une question ?</div>
                    <p>Service client :</p>
                    <p>01 XX XX XX XX</p>
                    <p>Du lundi au vendredi</p>
                    <p>De 09h00 à 18h00</p>
                    <p>Mail : XXXXXX</p>
                    <p>Instagram : @karinejeff</p>
                    <p>Questions fréquentes</p>';
        if (parent::install()
            && $this->registerHook('displayFooter')
            && Configuration::updateValue('KJ_FOOTERQUESTION', $html)
        ) {
            return true;
        }
        return false;
    }

    public function uninstall()
    {
        if (!parent::uninstall()
            && !Configuration::deleteByName('KJ_FOOTERQUESTION')) {
            return false;
        }
        return true;
    }

    public function getContent()
    {
        $output = '';

        if (Tools::isSubmit('saveps_customtext')) {
            if (!Tools::getValue('footertext')) {
                $output = $this->displayError($this->trans('Please fill out all fields.', [], 'Admin.Notifications.Error'));
            } else {
                $update = Configuration::updateValue('KJ_FOOTERQUESTION', Tools::getValue('footertext'),true);

                if (!$update) {
                    $output = '<div class="alert alert-danger conf error">'
                        . $this->trans('An error occurred on saving.', [], 'Admin.Notifications.Error')
                        . '</div>';
                }
            }
        }

        return $output . $this->renderForm();

    }

    public function hookDisplayFooter($params)
    {
        $this->context->smarty->assign(array("text"=>Configuration::get('KJ_FOOTERQUESTION')));
        return $this->display(__FILE__, 'kj_footerquestion.tpl');

    }

    protected function renderForm()
    {
        $defaultLang = (int)Configuration::get('PS_LANG_DEFAULT');

        $fields_form = [
            'tinymce' => true,
            'legend' => [
                'title' => $this->trans('CMS block', [], 'Modules.kj_footerquestion.Admin'),
            ],
            'input' =>[
                array(
                    'type' => 'textarea',
                    'label' => $this->trans('Text block', [], 'Modules.kj_footerquestion.Admin'),
                    'name' => 'footertext',
                    'cols' => 40,
                    'rows' => 10,
                    'class' => 'rte',
                    'autoload_rte' => true,
                )
            ],
            'submit' => [
                'title' => $this->trans('Save', [], 'Admin.Actions'),
            ],
            'buttons' => [
                [
                    'href' => AdminController::$currentIndex . '&configure=' . $this->name . '&token=' . Tools::getAdminTokenLite('AdminModules'),
                    'title' => $this->trans('Back to list', [], 'Admin.Actions'),
                    'icon' => 'process-icon-back',
                ],
            ],
        ];
        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->default_form_language =$defaultLang;
        $helper->module = $this;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'saveps_customtext';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->fields_value =array('footertext'=>Configuration::get('KJ_FOOTERQUESTION',$defaultLang));
        return $helper->generateForm([['form' => $fields_form]]);
    }

}